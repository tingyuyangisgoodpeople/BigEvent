$(function(){
  getUserInfo()
  
  //实现退出功能
  $('.tuichu').click(function(){
    layui.layer.confirm('是否退出系统?', {icon: 3, title:'提示'}, function(index){
      // 清除token信息
      localStorage.removeItem('token')
      // 跳转到登录页面
      location.href = '/login.html'
      layui.layer.close(index);
    })
  })
})
// 获取用户基本信息
function getUserInfo(){
  $('.layui-nav-img').hide()
  $.ajax({
    url: '/my/userinfo',
    method: 'GET',
    success: function(res){
      if(res.status !== 0){
      return  console.log('获取用户信息失败')
      }
      // 调用渲染用户头像函数
      renderAvatar(res.data)
    }
  })
}
// 渲染用户头像
function renderAvatar(user){
  // 获取用户名称
 const name = user.nickname || user.username
 $('.welcome').html('欢迎&nbsp;' + name)
//  渲染用户头像
if(user.user_pic !== null){
  $('.layui-nav-img').attr('src',user.user_pic).show()
  $('.text-avatar').hide()
}
else {
  let first = name[0].toUpperCase()
  $('.text-avatar').html(first).show()
  $('.layui-nav-img').hide()
}
}