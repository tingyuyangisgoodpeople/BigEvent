$(function(){
  // 初始化用户信息
  initUserInfo()
})
function initUserInfo(){
   $.ajax({
    url: '/my/userinfo',
    method: 'GET',
    success: function(res){
      if(res.status !== 0){
        return console.log('获取用户基本信息失败')
      }
      console.log(res)
      // 快速为表单赋值
      layui.form.val('userinfo',res.data)
    }
  })
}
  // 重置表单数据
  $('#btn_reset').click(function(e){
    e.preventDefault()
    initUserInfo()
  })
  // 修改用户信息
  $('.layui-form').submit(function(e){
    e.preventDefault()
    $.ajax({
      url: '/my/userinfo',
      method: 'POST',
      data: $(this).serialize(),
      success: function(res){
        if(res.status !== 0){
          return layui.layer.msg('修改用户信息失败！')
        }
        // 调用父页面的方法，重新渲染用户名
        layui.layer.msg('用户信息修改成功！')
        window.parent.getUserInfo()
      }
    })
  })

