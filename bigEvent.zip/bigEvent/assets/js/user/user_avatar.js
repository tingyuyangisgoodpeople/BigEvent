$(function(){
   // 1.1 获取裁剪区域的 DOM 元素
   var $image = $('#image')
   // 1.2 配置选项
   const options = {
       // 纵横比
       aspectRatio: 1,
       // 指定预览区域
       preview: '.img-preview'
   };

   // 1.3 创建裁剪区域
   $image.cropper(options)

   $('#btnChooseImage').click(function(){
    $('#file').click()

    $('#file').change(function(e){
      // 获取选择的文件
      const file = e.target.files

      // 拿到用户选择的文件
      const getFile = file[0]

      // 将文件转化为路径
      let imgUrl = URL.createObjectURL(getFile)

      // 重新初始化裁剪区域
      $image
      .cropper('destroy')
      .attr('src',imgUrl)
      .cropper(options)
      })
   })
   $('#btnUpload').click(function(){
    const dataURL = $image.cropper('getCroppedCanvas', {
      width: 100,
      heigeht: 100
  }).toDataURL('image/png')
  $.ajax({
    url: '/my/update/avatar',
    method: 'POST',
    data: {
      avatar: dataURL
    },
    success: function(res){
      if(res.status !== 0)return
      window.parent.getUserInfo()
    }
  })
   })
})