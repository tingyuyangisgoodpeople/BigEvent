$(function(){
initCateList()
})
// 获取文章分类列表
function initCateList(){
  $.ajax({
    url: '/my/article/cates',
    method: 'GET',
    success: function(res){
      if(res.status !== 0)
      return layui.layer.msg('获取文章列表失败')
      const html = template('tpl-table',res)
      $('tbody').html(html)
    }
  })
}
let indexAdd = null
$('.btnAddCate').click(function(){
  indexAdd = layui.layer.open({
          type: 1,
          title: '添加文章分类',
          content: $('#dialog-add').html(),
          area: ['500px', '250px']
      })
})
$('body').on('submit','#form-add', function(e){
  e.preventDefault()
  $.ajax({
    url: '/my/article/addcates',
    method: 'POST',
    data: $(this).serialize(),
    success: function(res){
      if(res.status !== 0){
        return console.log('更新文章分类失败')
      }
      initCateList()
      layui.layer.msg('更新文章成功')
      layui.layer.close(indexAdd)
    }
  })
})
var indexEdit = null
  $('tbody').on('click', '.btnEditCate', function (e) {
      indexEdit = layui.layer.open({
          type: 1,
          title: '修改文章分类',
          content: $('#dialog-edit').html(),
          area: ['500px', '250px']
      })
      let id = $(this).attr('data-id')
      $.ajax({
        url: '/my/article/cates/' + id,
        method: 'GET',
        success: function(res){
         layui.form.val('form-edit',res.data)
        
        }
      })
  })
  $('body').on('submit','#form-edit',function(e){
    e.preventDefault()
    $.ajax({
      url: '/my/article/updatecate',
      method: 'POST',
      data: $(this).serialize(),
      success: function(res){
        if(res.status !== 0){
          return console.log('修改文章分类失败')
        }
        initCateList()
        layui.layer.msg('修改文章成功')
        layui.layer.close(indexEdit)
      }
    })
  })
  $('tbody').on('click', '.btnDelCate', function (e) {
    const id = $(this).attr('data-id')
    layui.layer.confirm('确认删除?', { icon: 3, title: '提示' }, function (index) {
        $.ajax({
            method: 'GET',
            url: '/my/article/deletecate/'+ id,
            success: function (res) {
                if (res.status !== 0) {
                    return console.log('删除分类失败')
                }
                layui.layer.msg('message')
                layui.layer.close(index)
                initCateList()
            }
        })

    })
})