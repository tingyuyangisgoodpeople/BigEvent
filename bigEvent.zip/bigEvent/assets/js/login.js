// 入口函数
$(function() {
  // 添加点击去注册的链接的事件
  $('#link_reg').on('click', function(){
    $('.log-box').hide()
    $('.reg-box').show()
  })
  // 添加点击去登录的链接的事件
  $('#link_log').on('click', function(){
    $('.log-box').show()
    $('.reg-box').hide()
  })
  // layui转换
  const form = layui.form
  const layer =  layui.layer
  //自定义表单校验
  form.verify({
      pass: [
          /^[\S]{6,12}$/, '密码格式不规范'
      ],

      repass: function(newpwd) {
          var oldpwd = $('.reg-box [name=password]').val()

          if (newpwd != oldpwd) {
              return '两次密码不一致，请重新输入'
          }
      }
  })
  $('#form_reg').on('submit',function(e){
    e.preventDefault()
    $.ajax({
      url: '/api/reguser',
      method: 'POST',
    //  快速获取表单中的数据
      data: $(this).serialize(),
      success: function(res){
        if(res.status !== 0){
          return layer.msg(res.message)
        } 
        layer.msg('注册成功!')
        // 自动跳到登录页面
        const Timeout = window.setTimeout(function(){
          $('#link_log').trigger('click')
        },'3000') 
      }
    })
  })
 $('#form_log').submit(function(e){
  // window.clearTimeout(Timeout)
  e.preventDefault()
  $.ajax({
    url: '/api/login',
    method: 'POST',
    data: $(this).serialize(),
    success: function(res){
      if(res.status !== 0){
        return layer.msg('用户名或密码输入错误，请重新输入')
      }
      console.log(res.token)
      // 将登陆成功得到的token字符串保存到localStorage中
      localStorage.setItem('token',res.token)
      location.href = '/index.html'
    }
  })
 })

})